package com.odilu.sam;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int ink = Color.rgb(48, 31, 57);
    private final int plum = Color.rgb(38, 25, 49);
    private final int gold = Color.rgb(190, 145, 75);
    private final int paper = Color.rgb(246, 238, 223);
    private final int rose = Color.rgb(164, 101, 119);
    private LinearLayout root, content;
    private int reasonIndex = 0;

    private final String[] reasons = {
        "Porque desde que llegaste, mis días tienen algo diferente.",
        "Porque tu sonrisa tiene una forma muy bonita de alegrarme.",
        "Porque contigo hasta los momentos más sencillos se vuelven recuerdos especiales.",
        "Porque me encanta escucharte hablar de las cosas que te emocionan.",
        "Porque me haces sentir que estoy exactamente donde quiero estar.",
        "Porque amo nuestras risas, incluso cuando no hay ningún motivo para reírnos.",
        "Porque hasta una clase puede convertirse en uno de mis momentos favoritos si estoy contigo.",
        "Porque recuerdo con mucho cariño nuestras risas en el jardín.",
        "Porque me encanta descubrir cada pequeño detalle de ti.",
        "Porque quiero conocer todas tus versiones, incluso las que todavía no me has mostrado.",
        "Porque admiro la manera en que sigues adelante con tus días.",
        "Porque me gusta verte emocionada por tus Pokémon y escuchar cómo me cuentas de ellos.",
        "Porque no necesito un plan extraordinario para disfrutar de tu compañía.",
        "Porque tus abrazos hacen que el mundo se sienta un poquito más tranquilo.",
        "Porque contigo puedo ser yo misma sin tener que fingir nada.",
        "Porque me encanta la complicidad que estamos construyendo.",
        "Porque me haces querer guardar hasta los momentos más pequeños.",
        "Porque me gusta aprender cosas de ti y descubrir lo que te hace feliz.",
        "Porque cada conversación contigo me deja queriendo un ratito más.",
        "Porque me encanta la manera en que hemos comenzado a escribir nuestra historia.",
        "Porque no eres perfecta y tampoco necesito que lo seas; me encantas siendo tú.",
        "Porque quiero estar presente tanto en tus días bonitos como en los complicados.",
        "Porque me haces sentir afortunada de haberte encontrado.",
        "Porque incluso cuando estamos haciendo cualquier tontería, soy feliz contigo.",
        "Porque tienes una manera muy tuya de hacer que te extrañe.",
        "Porque quiero seguir celebrando tus logros y acompañándote en tus sueños.",
        "Porque me emociona imaginar todos los lugares y experiencias que todavía nos esperan.",
        "Porque si pudiera volver al día en que te conocí, volvería a acercarme a ti.",
        "Porque entre tantas posibilidades, mi corazón sigue encontrando razones para elegirte.",
        "Y porque después de estas 30 razones, todavía me quedan muchísimas más que descubrir y demostrarte."
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.SERIF, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(18, 10, 18, 10);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(22, 18, 22, 24);
        return l;
    }

    private void setup(String title) {
        root = column();
        root.setBackgroundColor(paper);
        setContentView(root);
        TextView brand = text("✦  OLIMPO DE LOS DOS  ✦", 12, gold, true);
        root.addView(brand);
        TextView heading = text(title, 28, ink, true);
        heading.setPadding(12, 8, 12, 16);
        root.addView(heading);
        ScrollView scroll = new ScrollView(this);
        content = column();
        content.setPadding(4, 4, 4, 20);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, 8, 0, 0);
        addNav(nav, "Inicio", this::showHome);
        addNav(nav, "30 razones", this::showReasons);
        addNav(nav, "Carta", this::showLetter);
        root.addView(nav);
    }

    private void addNav(LinearLayout nav, String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(11); b.setTextColor(ink);
        b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE8DCC8));
        b.setOnClickListener(v -> action.run());
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void card(String title, String body) {
        LinearLayout c = column();
        c.setBackground(bg(Color.WHITE, 28));
        c.setElevation(3);
        TextView h = text(title, 19, rose, true);
        TextView p = text(body, 16, ink, false);
        c.addView(h); c.addView(p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 10, 0, 12);
        content.addView(c, lp);
    }

    private void actionButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(15); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(plum));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(8, 12, 8, 8);
        content.addView(b, lp);
    }

    private void showHome() {
        setup("Un universo para Sam");
        card("♡  Mi querida Sam", "Hay personas que llegan a nuestra historia y hacen que todo tenga un brillo distinto. Esta pequeña parte del Olimpo la hice pensando en ti.");
        card("✧  Una historia elegida", "Desde el 15 de octubre comenzó una historia que quiero seguir llenando de momentos, risas y recuerdos contigo.");
        card("☼  Tu lugar en mi universo", "Si los dioses hubieran dibujado las estrellas para señalar algo bonito, me gusta pensar que una de ellas habría llevado tu nombre.");
        actionButton("Descubrir las 30 razones  ♡", this::showReasons);
        actionButton("Leer una carta de tu ingeniera  ✉", this::showLetter);
        TextView foot = text("Hecho con amor, para Sam.  •  Desde tu ingeniería bonita", 12, rose, false);
        content.addView(foot);
    }

    private void showReasons() {
        setup("30 razones para elegirte");
        card("El frasco de Afrodita", "Cada estrella guarda una razón. Toca el botón para descubrirlas una a una, sin prisa.");
        TextView counter = text("RAZÓN " + (reasonIndex + 1) + " DE 30", 12, gold, true);
        content.addView(counter);
        TextView note = text("✦  " + reasons[reasonIndex] + "  ✦", 21, ink, false);
        note.setBackground(bg(Color.WHITE, 28));
        note.setPadding(24, 35, 24, 35);
        content.addView(note);
        actionButton("Siguiente razón  →", () -> {
            reasonIndex = (reasonIndex + 1) % reasons.length;
            showReasons();
        });
        actionButton("Volver a la primera razón", () -> { reasonIndex = 0; showReasons(); });
    }

    private void showLetter() {
        setup("Un mensaje desde mi Olimpo");
        card("Para Sam ♡", "No sé si exista una forma perfecta de demostrarte cuánto te amo, pero quiero que nunca te falten razones para sentirte querida. Me encanta conocerte, descubrir cada parte de ti y compartir contigo hasta los momentos más sencillos.");
        card("Una promesa pequeña", "No necesito que todos nuestros días sean extraordinarios. Quiero seguir encontrando lo extraordinario en las cosas que vivimos juntas: una conversación, una risa en clase, una mirada o cualquier tontería que termine siendo un recuerdo.");
        card("Con todo mi amor", "Si algún día dudas de lo especial que eres para mí, vuelve a este pequeño universo. Estas 30 razones son apenas el comienzo; todavía quiero descubrir y demostrarte muchísimas más.\n\nTe elegiría en esta y en todas mis vidas.\n\n— Tu ingeniería bonita ♡");
    }
}