# Un universo para Sam — proyecto Android

Este proyecto es una aplicación Android nativa sencilla, sin dependencias externas, con estética inspirada en la mitología griega.

## Incluye
- Inicio con dedicatoria para Sam.
- Sección interactiva de 30 razones.
- Carta romántica.
- Navegación inferior entre secciones.
- Fecha especial: 15 de octubre.
- Personalización con referencias a sus recuerdos, sus risas en el jardín y sus Pokémon.

## Cómo generar el APK en Android Studio
1. Instala Android Studio en una computadora.
2. Descomprime este ZIP.
3. Abre Android Studio y selecciona **Open**; elige la carpeta `Sam_Un_Universo_Griego`.
4. Espera a que Gradle sincronice el proyecto. Se requiere conexión a internet la primera vez para descargar el complemento de Android.
5. En el menú **Build**, selecciona **Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio generará el archivo en `app/build/outputs/apk/debug/app-debug.apk`.
7. Pasa ese APK al teléfono Android de Sam e instálalo. Si Android lo solicita, permite instalar aplicaciones desde esa fuente.

## Datos técnicos
- Lenguaje: Java
- SDK de compilación: 35
- SDK mínimo: 23 (Android 6.0)
- Identificador: `com.odilu.sam`
- Versión: 1.0

## Nota
Este paquete contiene el proyecto fuente listo para abrir y compilar en Android Studio. No contiene un APK compilado: el entorno donde se preparó no dispone del Android SDK ni de las herramientas de compilación de Android.
